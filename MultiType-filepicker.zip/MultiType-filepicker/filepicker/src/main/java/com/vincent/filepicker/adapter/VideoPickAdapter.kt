package com.vincent.filepicker.adapter

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.core.content.FileProvider
import com.vincent.filepicker.filter.entity.VideoFile
import com.vincent.filepicker.adapter.VideoPickAdapter.VideoPickViewHolder
import com.vincent.filepicker.activity.VideoPickActivity
import com.vincent.filepicker.ToastUtil
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import androidx.recyclerview.widget.RecyclerView
import com.vincent.filepicker.Constant
import com.vincent.filepicker.R
import com.vincent.filepicker.Util
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * Created by Vincent Woo
 * Date: 2016/10/21
 * Time: 14:13
 */
class VideoPickAdapter(
    ctx: Context?,
    list: ArrayList<VideoFile?>?,
    private val isNeedCamera: Boolean,
    private val mMaxNumber: Int
) : BaseAdapter<VideoFile?, VideoPickViewHolder?>(
    ctx!!, list!!
) {
    private var mCurrentNumber = 0
    @JvmField
    var mVideoPath: String? = null

    constructor(ctx: Context?, needCamera: Boolean, max: Int) : this(
        ctx,
        ArrayList<VideoFile?>(),
        needCamera,
        max
    ) {
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoPickViewHolder {
        val itemView =
            LayoutInflater.from(mContext).inflate(R.layout.vw_layout_item_video_pick, parent, false)
        val params = itemView.layoutParams
        if (params != null) {
            val wm = mContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val width = wm.defaultDisplay.width
            params.height = width / VideoPickActivity.COLUMN_NUMBER
        }
        return VideoPickViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: VideoPickViewHolder, position: Int) {
        if (isNeedCamera && position == 0) {
            holder.mIvCamera.visibility = View.VISIBLE
            holder.mIvThumbnail.visibility = View.INVISIBLE
            holder.mCbx.visibility = View.INVISIBLE
            holder.mShadow.visibility = View.INVISIBLE
            holder.mDurationLayout.visibility = View.INVISIBLE
            holder.itemView.setOnClickListener {
                val intent = Intent(MediaStore.ACTION_VIDEO_CAPTURE)
                val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(Date())
                val file = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).absolutePath
                            + "/VID_" + timeStamp + ".mp4"
                )
                mVideoPath = file.absolutePath
                val contentValues = ContentValues(1)
                contentValues.put(MediaStore.Images.Media.DATA, mVideoPath)
                val uri = mContext.contentResolver.insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    contentValues
                )
                intent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
                intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1)
                if (Util.detectIntent(mContext, intent)) {
                    (mContext as Activity).startActivityForResult(
                        intent,
                        Constant.REQUEST_CODE_TAKE_VIDEO
                    )
                } else {
                    ToastUtil.getInstance(mContext)
                        .showToast(mContext.getString(R.string.vw_no_video_app))
                }
            }
        } else {
            holder.mIvCamera.visibility = View.INVISIBLE
            holder.mIvThumbnail.visibility = View.VISIBLE
            holder.mCbx.visibility = View.VISIBLE
            holder.mDurationLayout.visibility = View.VISIBLE
            val file: VideoFile
            file = if (isNeedCamera) {
                mList[position - 1]!!
            } else {
                mList[position]!!
            }
            val options = RequestOptions()
            Glide.with(mContext)
                .load(file.path)
                .apply(options.centerCrop())
                .transition(DrawableTransitionOptions.withCrossFade()) //                    .transition(new DrawableTransitionOptions().crossFade(500))
                .into(holder.mIvThumbnail)
            if (file.isSelected) {
                holder.mCbx.isSelected = true
                holder.mShadow.visibility = View.VISIBLE
            } else {
                holder.mCbx.isSelected = false
                holder.mShadow.visibility = View.INVISIBLE
            }
            holder.mCbx.setOnClickListener(View.OnClickListener { v ->
                if (!v.isSelected && isUpToMax) {
                    ToastUtil.getInstance(mContext).showToast(R.string.vw_up_to_max)
                    return@OnClickListener
                }
                if (v.isSelected) {
                    holder.mShadow.visibility = View.INVISIBLE
                    holder.mCbx.isSelected = false
                    mCurrentNumber--
                } else {
                    holder.mShadow.visibility = View.VISIBLE
                    holder.mCbx.isSelected = true
                    mCurrentNumber++
                }
                val index = if (isNeedCamera) holder.adapterPosition - 1 else holder.adapterPosition
                mList[index]!!.isSelected = holder.mCbx.isSelected
                if (mListener != null) {
                    mListener!!.OnSelectStateChanged(holder.mCbx.isSelected, mList[index])
                }
            })
            holder.itemView.setOnClickListener {
                val intent = Intent(Intent.ACTION_VIEW)
                val uri: Uri
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    intent.flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                    val f = File(file.path)
                    uri = FileProvider.getUriForFile(
                        mContext,
                        mContext.applicationContext.packageName + ".provider",
                        f
                    )
                } else {
                    uri = Uri.parse("file://" + file.path)
                }
                intent.setDataAndType(uri, "video/mp4")
                if (Util.detectIntent(mContext, intent)) {
                    mContext.startActivity(intent)
                } else {
                    ToastUtil.getInstance(mContext)
                        .showToast(mContext.getString(R.string.vw_no_video_play_app))
                }
            }
            holder.mDuration.text = Util.getDurationString(file.duration)
        }
    }

    override fun getItemCount(): Int {
        return if (isNeedCamera) mList.size + 1 else mList.size
    }

    inner class VideoPickViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val mIvCamera: ImageView
        val mIvThumbnail: ImageView
        val mShadow: View
        val mCbx: ImageView
        val mDuration: TextView
        val mDurationLayout: RelativeLayout

        init {
            mIvCamera = itemView.findViewById<View>(R.id.iv_camera) as ImageView
            mIvThumbnail = itemView.findViewById<View>(R.id.iv_thumbnail) as ImageView
            mShadow = itemView.findViewById(R.id.shadow)
            mCbx = itemView.findViewById<View>(R.id.cbx) as ImageView
            mDuration = itemView.findViewById<View>(R.id.txt_duration) as TextView
            mDurationLayout = itemView.findViewById<View>(R.id.layout_duration) as RelativeLayout
        }
    }

    val isUpToMax: Boolean
        get() = mCurrentNumber >= mMaxNumber

    fun setCurrentNumber(number: Int) {
        mCurrentNumber = number
    }
}