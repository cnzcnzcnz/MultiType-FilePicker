package com.vincent.filepicker.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.vincent.filepicker.R
import com.vincent.filepicker.ToastUtil
import com.vincent.filepicker.Util
import com.vincent.filepicker.filter.entity.NormalFile
import java.util.ArrayList

/**
 * Created by Vincent Woo
 * Date: 2016/10/26
 * Time: 10:23
 */
class NormalFilePickAdapter(
    ctx: Context?,
    list: ArrayList<NormalFile?>?,
    private val mMaxNumber: Int
) : BaseAdapter<NormalFile?, NormalFilePickAdapter.NormalFilePickViewHolder?>(
    ctx!!, list!!
) {
    private var mCurrentNumber = 0

    constructor(ctx: Context?, max: Int) : this(ctx, ArrayList<NormalFile?>(), max) {}

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NormalFilePickViewHolder {
        val itemView = LayoutInflater.from(mContext)
            .inflate(R.layout.vw_layout_item_normal_file_pick, parent, false)
        return NormalFilePickViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: NormalFilePickViewHolder, position: Int) {
        val file: NormalFile = mList[position]!!
        holder.mTvTitle.text = Util.extractFileNameWithSuffix(file.getPath())
        holder.mTvTitle.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        if (holder.mTvTitle.measuredWidth >
            Util.getScreenWidth(mContext) - Util.dip2px(
                mContext,
                (10 + 32 + 10 + 48 + 10 * 2).toFloat()
            )
        ) {
            holder.mTvTitle.setLines(2)
        } else {
            holder.mTvTitle.setLines(1)
        }
        holder.mCbx.isSelected = file.isSelected
        if (file.getPath().endsWith("xls") || file.getPath().endsWith("xlsx")) {
            holder.mIvIcon.setImageResource(R.drawable.vw_ic_excel)
        } else if (file.getPath().endsWith("doc") || file.getPath().endsWith("docx")) {
            holder.mIvIcon.setImageResource(R.drawable.vw_ic_word)
        } else if (file.getPath().endsWith("ppt") || file.getPath().endsWith("pptx")) {
            holder.mIvIcon.setImageResource(R.drawable.vw_ic_ppt)
        } else if (file.getPath().endsWith("pdf")) {
            holder.mIvIcon.setImageResource(R.drawable.vw_ic_pdf)
        } else if (file.getPath().endsWith("txt")) {
            holder.mIvIcon.setImageResource(R.drawable.vw_ic_txt)
        } else {
            holder.mIvIcon.setImageResource(R.drawable.vw_ic_file)
        }
        holder.mCbx.setOnClickListener(View.OnClickListener { v ->
            if (!v.isSelected && isUpToMax) {
                ToastUtil.getInstance(mContext).showToast(R.string.vw_up_to_max)
                return@OnClickListener
            }
            if (v.isSelected) {
                holder.mCbx.isSelected = false
                mCurrentNumber--
            } else {
                holder.mCbx.isSelected = true
                mCurrentNumber++
            }
            mList[holder.absoluteAdapterPosition]!!.setSelected(holder.mCbx.isSelected)
            if (mListener != null) {
                mListener!!.OnSelectStateChanged(
                    holder.mCbx.isSelected,
                    mList[holder.getAdapterPosition()]
                )
            }
        })

//        holder.itemView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Uri uri = Uri.parse("file://" + file.getPath());
//                Intent intent = new Intent(Intent.ACTION_VIEW);
//                intent.setDataAndType(uri, "audio/mp3");
//                if (Util.detectIntent(mContext, intent)) {
//                    mContext.startActivity(intent);
//                } else {
//                    Toast.makeText(mContext, "No Application exists for audio!", Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
    }

    override fun getItemCount(): Int {
        return mList.size
    }

    inner class NormalFilePickViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val mIvIcon: ImageView
        val mTvTitle: TextView
        val mCbx: ImageView

        init {
            mIvIcon = itemView.findViewById<View>(R.id.ic_file) as ImageView
            mTvTitle = itemView.findViewById<View>(R.id.tv_file_title) as TextView
            mCbx = itemView.findViewById<View>(R.id.cbx) as ImageView
        }
    }

    private val isUpToMax: Boolean
        private get() = mCurrentNumber >= mMaxNumber
}