package com.vincent.filepicker.adapter

/**
 * Created by Vincent Woo
 * Date: 2016/10/14
 * Time: 16:06
 */
interface OnSelectStateListener<T> {
    fun OnSelectStateChanged(state: Boolean, file: T)
}