package com.vincent.filepicker.adapter

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import com.vincent.filepicker.R
import com.vincent.filepicker.ToastUtil
import com.vincent.filepicker.Util
import com.vincent.filepicker.filter.entity.AudioFile
import java.io.File
import com.vincent.filepicker.adapter.OnSelectStateListener as OnSelectStateListener

/**
 * Created by Vincent Woo
 * Date: 2016/10/25
 * Time: 10:57
 */
class AudioPickAdapter(ctx: Context, list: ArrayList<AudioFile>, private var mMaxNumber: Int) :
    BaseAdapter<AudioFile, AudioPickAdapter.AudioPickViewHolder>(ctx, list) {
    private var mCurrentNumber = 0

    override fun onBindViewHolder(holder: AudioPickViewHolder, position: Int) {
        val file = mList!![position]!!
        holder.mTvTitle.text = file.name
        holder.mTvTitle.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        if (holder.mTvTitle.measuredWidth >
            Util.getScreenWidth(mContext) - Util.dip2px(
                mContext,
                (10 + 32 + 10 + 48 + 10 * 2).toFloat()
            )
        ) {
            holder.mTvTitle.setLines(2)
        } else {
            holder.mTvTitle.setLines(1)
        }
        holder.mTvDuration.text = Util.getDurationString(file.duration)
        holder.mCbx.isSelected = file.isSelected
        holder.mCbx.setOnClickListener(View.OnClickListener { v ->
            if (!v.isSelected && isUpToMax) {
                ToastUtil.getInstance(mContext).showToast(R.string.vw_up_to_max)
                return@OnClickListener
            }
            if (v.isSelected) {
                holder.mCbx.isSelected = false
                mCurrentNumber--
            } else {
                holder.mCbx.isSelected = true
                mCurrentNumber++
            }
            mList[holder.absoluteAdapterPosition].isSelected = holder.mCbx.isSelected
            mListener!!.OnSelectStateChanged(
                holder.mCbx.isSelected,
                mList[holder.absoluteAdapterPosition]!!
            )
        })
        holder.itemView.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW)
            val uri: Uri
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                intent.flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                val f = File(file.path)
                uri = FileProvider.getUriForFile(
                    mContext!!,
                    mContext!!.applicationContext.packageName + ".provider",
                    f
                )
            } else {
                uri = Uri.parse("file://" + file.path)
            }
            intent.setDataAndType(uri, "audio/mp3")
            if (Util.detectIntent(mContext, intent)) {
                mContext!!.startActivity(intent)
            } else {
                ToastUtil.getInstance(mContext)
                    .showToast(mContext!!.getString(R.string.vw_no_audio_play_app))
            }
        }
    }

    inner class AudioPickViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val mTvTitle: TextView
        val mTvDuration: TextView
        val mCbx: ImageView

        init {
            mTvTitle = itemView.findViewById<View>(R.id.tv_audio_title) as TextView
            mTvDuration = itemView.findViewById<View>(R.id.tv_duration) as TextView
            mCbx = itemView.findViewById<View>(R.id.cbx) as ImageView
        }
    }

    val isUpToMax: Boolean
        get() = mCurrentNumber >= mMaxNumber

    fun setCurrentNumber(number: Int) {
        mCurrentNumber = number
    }

    override fun getItemCount(): Int {
        return mList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AudioPickViewHolder {
        val itemView =
            LayoutInflater.from(mContext).inflate(R.layout.vw_layout_item_audio_pick, parent, false)
        return AudioPickViewHolder(itemView)
    }
}