package com.vincent.filepicker.adapter

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.RequestOptions
import com.vincent.filepicker.Constant
import com.vincent.filepicker.R
import com.vincent.filepicker.ToastUtil
import com.vincent.filepicker.Util
import com.vincent.filepicker.activity.ImageBrowserActivity
import com.vincent.filepicker.activity.ImagePickActivity
import com.vincent.filepicker.filter.entity.ImageFile
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 * Created by Vincent Woo
 * Date: 2016/10/13
 * Time: 16:07
 */
class ImagePickAdapter(
    ctx: Context,
    list: ArrayList<ImageFile>,
    private val isNeedCamera: Boolean,
    private val isNeedImagePager: Boolean,
    private val mMaxNumber: Int
) : BaseAdapter<ImageFile, ImagePickAdapter.ImagePickViewHolder>(
    ctx, list
) {
    private var mCurrentNumber = 0
    @JvmField
    var mImagePath: String? = null
    @JvmField
    var mImageUri: Uri? = null

    constructor(ctx: Context, needCamera: Boolean, isNeedImagePager: Boolean, max: Int) : this(
        ctx,
        ArrayList<ImageFile>(),
        needCamera,
        isNeedImagePager,
        max
    ) {
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImagePickViewHolder {
        val itemView =
            LayoutInflater.from(mContext).inflate(R.layout.vw_layout_item_image_pick, parent, false)
        val params = itemView.layoutParams
        if (params != null) {
            val wm = mContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val width = wm.defaultDisplay.width
            params.height = width / ImagePickActivity.COLUMN_NUMBER
        }
        return ImagePickViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ImagePickViewHolder, position: Int) {
        if (isNeedCamera && position == 0) {
            holder.mIvCamera.visibility = View.VISIBLE
            holder.mIvThumbnail.visibility = View.INVISIBLE
            holder.mCbx.visibility = View.INVISIBLE
            holder.mShadow.visibility = View.INVISIBLE
            holder.itemView.setOnClickListener(View.OnClickListener {
                val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(Date())
                val file = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM).absolutePath
                            + "/IMG_" + timeStamp + ".jpg"
                )
                mImagePath = file.absolutePath
                val contentValues = ContentValues(1)
                contentValues.put(MediaStore.Images.Media.DATA, mImagePath)
                mImageUri = mContext.contentResolver.insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    contentValues
                )
                intent.putExtra(MediaStore.EXTRA_OUTPUT, mImageUri)
                if (Util.detectIntent(mContext, intent)) {
                    (mContext as Activity).startActivityForResult(
                        intent,
                        Constant.REQUEST_CODE_TAKE_IMAGE
                    )
                } else {
                    ToastUtil.getInstance(mContext)
                        .showToast(mContext.getString(R.string.vw_no_photo_app))
                }
            })
        } else {
            holder.mIvCamera.visibility = View.INVISIBLE
            holder.mIvThumbnail.visibility = View.VISIBLE
            holder.mCbx.visibility = View.VISIBLE
            val file: ImageFile
            file = if (isNeedCamera) {
                mList[position - 1]
            } else {
                mList[position]
            }
            val options = RequestOptions()
            Glide.with(mContext)
                .load(file.getPath())
                .apply(options.centerCrop())
                .transition(DrawableTransitionOptions.withCrossFade()) //                    .transition(new DrawableTransitionOptions().crossFade(500))
                .into(holder.mIvThumbnail)
            if (file.isSelected()) {
                holder.mCbx.isSelected = true
                holder.mShadow.visibility = View.VISIBLE
            } else {
                holder.mCbx.isSelected = false
                holder.mShadow.visibility = View.INVISIBLE
            }
            holder.mCbx.setOnClickListener(View.OnClickListener { v ->
                if (!v.isSelected && isUpToMax) {
                    ToastUtil.getInstance(mContext).showToast(R.string.vw_up_to_max)
                    return@OnClickListener
                }
                val index: Int =
                    if (isNeedCamera) holder.getAdapterPosition() - 1 else holder.getAdapterPosition()
                if (v.isSelected) {
                    holder.mShadow.visibility = View.INVISIBLE
                    holder.mCbx.isSelected = false
                    mCurrentNumber--
                    mList[index].setSelected(false)
                } else {
                    holder.mShadow.visibility = View.VISIBLE
                    holder.mCbx.isSelected = true
                    mCurrentNumber++
                    mList[index].setSelected(true)
                }
                if (mListener != null) {
                    mListener!!.OnSelectStateChanged(holder.mCbx.isSelected, mList[index])
                }
            })
            if (isNeedImagePager) {
                holder.itemView.setOnClickListener(View.OnClickListener {
                    val intent = Intent(mContext, ImageBrowserActivity::class.java)
                    intent.putExtra(Constant.MAX_NUMBER, mMaxNumber)
                    intent.putExtra(
                        ImageBrowserActivity.IMAGE_BROWSER_INIT_INDEX,
                        if (isNeedCamera) holder.getAdapterPosition() - 1 else holder.getAdapterPosition()
                    )
                    intent.putParcelableArrayListExtra(
                        ImageBrowserActivity.IMAGE_BROWSER_SELECTED_LIST,
                        (mContext as ImagePickActivity).mSelectedList
                    )
                    (mContext as Activity).startActivityForResult(
                        intent,
                        Constant.REQUEST_CODE_BROWSER_IMAGE
                    )
                })
            } else {
                holder.mIvThumbnail.setOnClickListener(View.OnClickListener {
                    if (!holder.mCbx.isSelected && isUpToMax) {
                        ToastUtil.getInstance(mContext).showToast(R.string.vw_up_to_max)
                        return@OnClickListener
                    }
                    val index: Int =
                        if (isNeedCamera) holder.getAdapterPosition() - 1 else holder.getAdapterPosition()
                    if (holder.mCbx.isSelected) {
                        holder.mShadow.visibility = View.INVISIBLE
                        holder.mCbx.isSelected = false
                        mCurrentNumber--
                        mList[index].setSelected(false)
                    } else {
                        holder.mShadow.visibility = View.VISIBLE
                        holder.mCbx.isSelected = true
                        mCurrentNumber++
                        mList[index].setSelected(true)
                    }
                    if (mListener != null) {
                        mListener!!.OnSelectStateChanged(holder.mCbx.isSelected, mList[index])
                    }
                })
            }
        }
    }

    override fun getItemCount(): Int {
        return if (isNeedCamera) mList.size + 1 else mList.size
    }

    inner class ImagePickViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val mIvCamera: ImageView
        val mIvThumbnail: ImageView
        val mShadow: View
        val mCbx: ImageView

        init {
            mIvCamera = itemView.findViewById<View>(R.id.iv_camera) as ImageView
            mIvThumbnail = itemView.findViewById<View>(R.id.iv_thumbnail) as ImageView
            mShadow = itemView.findViewById(R.id.shadow)
            mCbx = itemView.findViewById<View>(R.id.cbx) as ImageView
        }
    }

    val isUpToMax: Boolean
        get() = mCurrentNumber >= mMaxNumber

    fun setCurrentNumber(number: Int) {
        mCurrentNumber = number
    }
}